#ifndef TRANSACTION_H
#define TRANSACTION_H

#include <oci.h>

#define MAX_NAME 50
#define DB_USER "C##DEV"
#define DB_PASS "2941"
#define DB_CONN "localhost:1521/xe"
#define FILE_NAME "transactions.csv"

// �ŷ� ����ü ����
typedef struct Transaction {
    int id;
    char customer[MAX_NAME];
    char stock[MAX_NAME];
    int type;
    int quantity;
    double price;
    struct Transaction* next;
} Transaction;

// ���� ���� ����
extern Transaction* head;
extern int transactionCount;

void saveToFile();
void loadFromFile();
void freeMemory();
void searchTransaction();

void saveToStocksFile();
void loadFromStocksFile();

// DB ���� �Լ�
void initOCI();
void closeOCI();
void addTransaction();
void viewAllTransactions();
void updateTransaction();
void deleteTransaction();

#endif